/*To measure the  elapsed time of the matrix multiplication 
 by Jaewon Lee 32193430@dankook.ac.kr*/
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/time.h>

void cashe_perfo(size)
{
int i, j, k, r1, r2, r3;
int **B;
int **C;
int **A;
int s = size-2;
int s1 = size; 

A = (int**)malloc(sizeof(int*)*(s1)); //Matrix Memory Allocation
B = (int**)malloc(sizeof(int*)*(s1));
C = (int**)malloc(sizeof(int*)*(s1));
for(i=0;i<s; i++){
A[i] = (int*)malloc(sizeof(int)*s1); 
//A[i+1] = (int*)malloc(sizeof(int)*s);
//A[i+2] = (int*)malloc(sizeof(int)*s); 
B[i] = (int*)malloc(sizeof(int)*s1);
//B[i+1] = (int*)malloc(sizeof(int)*s);
//B[i+2] = (int*)malloc(sizeof(int)*s);
C[i] = (int*)malloc(sizeof(int)*s1);
//C[i+1] = (int*)malloc(sizeof(int)*s);
//C[i+2] = (int*)malloc(sizeof(int)*s);
}
/*
for(i=0; i<s; i++){ //Put numbers in the matrix
    for(j=0; j<s; j++){
        A[i][j] = (int) rand() / (int) RAND_MAX;
        B[i][j] = (int) rand() / (int) RAND_MAX;
        C[i][j] = 0; 
    }
}*/
// 가장 나쁜 성능
/*for(j=0; j<size;j++)
    for(k=0; k<size; k++){
    r = B[k][j];
        for(i=0; i<size; i++)
            C[i][j] += A[i][k]*r;
}
*/

for(i=0; i<s; i+=3)
    for(k=0; k<s; k+=3){
    B[i][k] = (int) rand() / (int) RAND_MAX;
    B[i+1][k+1] = (int) rand() / (int) RAND_MAX;
    B[i+2][k+2] = (int) rand() / (int) RAND_MAX;
    r1 = B[i][k]; r2 = B[i+1][k+1]; r3 = B[i+2][k+2];
        for(j=0; j<s; j+=3)
            C[i][j] = 0; C[i+1][j+1] = 0; C[i+2][j+2] = 0;
            A[k][j] = (int) rand() / (int) RAND_MAX;
            A[k+1][j+1] = (int) rand() / (int) RAND_MAX;
            A[k+2][j+2] = (int) rand() / (int) RAND_MAX;
            C[i][j] += A[k][j] * r1;
            C[i+1][j+1] += A[k+1][j+1] * r2;
            C[i+2][j+2] += A[k+2][j+2] * r3;
}

for(i=0; i<s;i++){ //Deallocate the memory blocks to avoid memory leaks
    free(A[i]);
    free(B[i]);
    free(C[i]);
}
free(A);
free(B);
free(C);
}

int main(int argc, char *argv[])
{
int i, loop = 0; struct timeval stime, etime, gap;

if(argc == 2){
loop = atoi(argv[1]);
gettimeofday(&stime, NULL);
cashe_perfo(loop);
gettimeofday(&etime, NULL);
gap.tv_sec = etime.tv_sec - stime.tv_sec;
gap.tv_usec = etime.tv_usec - stime.tv_usec;
if(gap.tv_usec < 0){
gap.tv_sec = gap.tv_sec - 1;
gap.tv_usec = gap.tv_usec + 1000000;
}
printf("Elapsed time %ldsec: %ldusec\n", gap.tv_sec, gap.tv_usec);

}
else
printf("Usage:command loop_size\n");
}
