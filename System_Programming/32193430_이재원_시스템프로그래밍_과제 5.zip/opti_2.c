/*To measure the  elapsed time of the matrix multiplication 
 by Jaewon Lee 32193430@dankook.ac.kr*/
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/time.h>

void cashe_perfo(size)
{
int i, j, k, r;
int **B;
int **C;
int **A;
int s = size;

A = (int**)malloc(sizeof(int*)*s); //Matrix Memory Allocation
B = (int**)malloc(sizeof(int*)*s);
C = (int**)malloc(sizeof(int*)*s);
for(i=0;i<s; i++){
A[i] = (int*)malloc(sizeof(int)*s);
B[i] = (int*)malloc(sizeof(int)*s);
C[i] = (int*)malloc(sizeof(int)*s);
}
/*
for(i=0; i<s; i++){ //Put numbers in the matrix
    for(j=0; j<s; j++){
        A[i][j] = (int) rand() / (int) RAND_MAX;
        B[i][j] = (int) rand() / (int) RAND_MAX;
        C[i][j] = 0; 
    }
}*/
// 가장 나쁜 성능
/*for(j=0; j<size;j++)
    for(k=0; k<size; k++){
    r = B[k][j];
        for(i=0; i<size; i++)
            C[i][j] += A[i][k]*r;
}
*/

// Code Motion: Put numbers and multiply matrix
for(i=0; i<s; i++)
    for(k=0; k<s; k++){
    B[i][k] = (int) rand() / (int) RAND_MAX;
    r = B[i][k]; 
        for(j=0; j<s; j++)
            C[i][j] = 0; 
            A[k][j] = (int) rand() / (int) RAND_MAX;
            C[i][j] += A[k][j]*r;
            
}

for(i=0; i<s;i++){ //Deallocate the memory blocks to avoid memory leaks
    free(A[i]);
    free(B[i]);
    free(C[i]);
}
free(A);
free(B);
free(C);
}

int main(int argc, char *argv[])
{
int i, loop = 0; struct timeval stime, etime, gap;
int A[10][10] = {1,};

if(argc == 2){
loop = atoi(argv[1]);
gettimeofday(&stime, NULL);
cashe_perfo(loop);
gettimeofday(&etime, NULL);
gap.tv_sec = etime.tv_sec - stime.tv_sec;
gap.tv_usec = etime.tv_usec - stime.tv_usec;
if(gap.tv_usec < 0){
gap.tv_sec = gap.tv_sec - 1;
gap.tv_usec = gap.tv_usec + 1000000;
}
printf("Elapsed time %ldsec: %ldusec\n", gap.tv_sec, gap.tv_usec);

}
else
printf("Usage:command loop_size\n");
}
