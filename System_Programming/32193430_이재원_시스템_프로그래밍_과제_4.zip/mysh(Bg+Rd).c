/*mysh.c: my shell program(parsing, fork, execve)
+Backgrond processing + Redirection 
Jaewon Lee 32193430 dankook.ac.kr*/
#include <stdio.h>
#include <fcntl.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#define MAX_ARG 128

void run();
int process(char* instr);
void run(){
char line[1024];
while(1){
dup2(1,STDOUT_FILENO);
printf("%s J1-shell $", get_current_dir_name());
fgets(line, sizeof(line)-1, stdin);
if(line == "\n") continue;
process(line);
}
}

int process(char * instr){
char *tokens[MAX_ARG], *token;
int i = 0, bg = 1, redirection = 0, pipe = 0, fd, tempfd;
pid_t pid; /*Process Id*/
for(;instr[i];i++){
switch(instr[i]){
case '>' :
token = strtok(&instr[i+1]," ");// 공백에 따라 나눈다.

fd = open(token, O_WRONLY | O_CREAT | O_TRUNC, 0664);
if(fd < 0) return 0;
tempfd = dup(STDOUT_FILENO);
dup2(fd, STDOUT_FILENO);
close(fd);
instr[i] = '\0';
redirection = 1;
break;
}
}
token = strtok(instr, " ");
if(token == NULL) return 0;
for(i=0; i< MAX_ARG && token != NULL; i++){
tokens[i] = token;
token = strtok(NULL, " ");
if(i == MAX_ARG - 1){
tokens[i] = (char*)0;
break;
} else
if(token == NULL){
tokens[i+1] = (char*)0;
break;
}
}
if(tokens[i][0] == '&'){
bg = 0;
tokens[i] = (char*)0;
}

switch(pid = fork()){
case -1:
printf("error fork\n");
case 0:
execvp(tokens[0], tokens);
default:
if(bg) wait();//background
if(redirection){
dup2(tempfd, STDOUT_FILENO);
close(tempfd);
}
break;
}
return -1;
}

int main(){
pid_t pid;
printf("Jaewon shell start\n\n");
run();
return 0;
}

