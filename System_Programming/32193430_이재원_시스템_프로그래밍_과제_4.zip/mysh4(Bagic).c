/*mysh4.c: my shell program(parsing, fork, exeve)*/
#include <stdio.h> 
#include <stdlib.h> 
#include <unistd.h>
#include <string.h> 
#include <sys/wait.h> 
#include <sys/types.h> 
#define MAXLINE 64

int main(int argc, char **argv) { 
char buf[MAXLINE];
pid_t pid;


while (1) {
printf("%s J1-shell $", get_current_dir_name());
memset(buf, 0x00, MAXLINE);
fgets(buf, MAXLINE - 1, stdin);
// char *fgets (char *string, int n, FILE *stream)
if (strncmp(buf, "exit\n", 5) == 0) {
break;
}
buf[strlen(buf) - 1] = 0x00; // Remove Keyboard Input(Enter)
pid = fork();
if (pid == 0) {
if (execlp(buf, buf, NULL) == -1) {	// execl() -> execlp()
printf("Command Not Found\n");
exit(0);
}
}
if(pid > 0){
wait(NULL);
}
}
return 0;
}
